package com.dicoding.picodiploma.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class register_activity extends AppCompatActivity {
    database_helper sqLiteDatabase;
    EditText Username, Password, password_confir;
    Button login, register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_activity);

        sqLiteDatabase = new database_helper(this);

        Username = findViewById(R.id.username_register);
        Password = findViewById(R.id.password_register);
        password_confir = findViewById(R.id.password_confir);
        login = findViewById(R.id.submit_btn_loginregister);
        register= findViewById(R.id.submit_btn_register);

        //login
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent LoginIntent = new Intent(register_activity.this, login.class);
                startActivity(LoginIntent);
                finish();
            }
        });
        //register
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String strUsername = Username.getText().toString();
                String strPassword = Password.getText().toString();
                String strPasswordConf = password_confir.getText().toString();
                if(strPassword.equals(strPasswordConf)){
                    Boolean Daftar = sqLiteDatabase.insertUser(strUsername,strPassword);
                    if(Daftar==true){
                        Toast.makeText(getApplicationContext(), "DAFTAR BERHASIL", Toast.LENGTH_SHORT).show();
                        Intent loginIntent = new Intent(register_activity.this,login.class);
                        startActivity(loginIntent);
                        finish();
                    }
                    else {
                        Toast.makeText(getApplicationContext(), "DAFTAR GAGAL", Toast.LENGTH_SHORT).show();
                    }

                }
                else {
                    Toast.makeText(getApplicationContext(),"PASSWORD TIDAK COCOK", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
