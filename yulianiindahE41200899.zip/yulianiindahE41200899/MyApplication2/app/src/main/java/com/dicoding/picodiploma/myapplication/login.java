package com.dicoding.picodiploma.myapplication;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class login extends AppCompatActivity {
    database_helper sqLiteDatabase;
    EditText Username, Password;
    Button login, register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        sqLiteDatabase = new database_helper(this);
        Username = findViewById(R.id.Username);
        Password = findViewById(R.id.Password);
        login = findViewById(R.id.submit_btn);
        register = findViewById(R.id.register);
        //REGISTER
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent registerIntent = new Intent(login.this, register_activity.class);
                startActivity(registerIntent);
                finish();
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String strUsername = Username.getText().toString();
                String strPassword = Password.getText().toString();
                Boolean masuk = sqLiteDatabase.checkLogin(strUsername,strPassword);
                if(masuk==true){
                    Boolean updateSession = sqLiteDatabase.upgradeSession("ada", 1);
                    if(updateSession == true) {
                        Toast.makeText(getApplicationContext(), "BERHASIL MASUK", Toast.LENGTH_SHORT).show();
                        Intent mainIntent = new Intent(login.this, content_login_activity.class);
                        startActivity(mainIntent);
                        finish();
                    }
                }
                else
                {
                    Toast.makeText(getApplicationContext(), "GAGAL MASUK" + strUsername, Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

}
