package com.dicoding.picodiploma.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class content_login_activity extends AppCompatActivity {
    database_helper sqLiteDatabase;
    Button logout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_login);

        sqLiteDatabase = new database_helper(this);
        logout=(Button)findViewById(R.id.btn_logout);
        Boolean checkSession = sqLiteDatabase.checkSession("ada");
        if (checkSession==true){
            Intent loginIntent = new Intent(content_login_activity.this,login.class);
            startActivity(loginIntent);
            finish();
        }
        //logout
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Boolean updateSession = sqLiteDatabase.upgradeSession("ada", 1);
                if(updateSession==true){
                    Toast.makeText(getApplicationContext(), "BERHASIL LOG OUT", Toast.LENGTH_SHORT).show();
                    Intent loginIntent = new Intent(content_login_activity.this, login.class);
                    startActivity(loginIntent);
                    finish();
                }
            }
        });
    }



}
